
public class Encryption {
	public native byte[] encrypt(byte[] data,byte[] key);
}
