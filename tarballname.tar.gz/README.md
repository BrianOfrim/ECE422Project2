# ECE422 Project2
Brian Ofrim (1374053)

Passwords hashed using SHA-1

To compile run the two following commands:
make
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.

Sources:
Password hashing:
	https://stackoverflow.com/questions/4895523/java-string-to-sha1
Diffie Helman Key exchange (used to generate a shared secret key for TEA):
	https://docs.oracle.com/javase/8/docs/technotes/guides/security/crypto/CryptoSpec.html#DH2Ex
Writing to files:
	http://beginnersbook.com/2014/01/how-to-append-to-a-file-in-java/
