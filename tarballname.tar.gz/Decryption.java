
public class Decryption {
	public native byte[] decrypt(byte[] data,byte[] key);
}
